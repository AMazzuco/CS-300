//============================================================================
// Name        : Source.cpp
// Author      : Alyssa Mazzucotelli
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Project 2: Vector sorting courses
//============================================================================

#include <algorithm>
#include <iostream>
#include <vector>

#include "CSVparser.hpp"

using namespace std;

//define structure to hold course info
struct Course {
	string courseNumber;
	string courseName;
	vector<string> prereq;
	int preReqs = 0;
};

vector<Course> loadCourses(string csvPath) {
	//define vector data structure to hold courses
	vector<Course> courses;

	//initialize the CSV Parser using the given path
	csv::Parser file = csv::Parser(csvPath);
	// I did not realize that this required a header and also does not work if the
	// rows do not contain the same amount of inputs 
	try {
		//loop to read rows of CSV file
		for (unsigned int i = 0; i < file.rowCount(); i++)
		{
			if (file[i][1].size() == 0 || file[i][2].size() == 0) {
				cout << "Error not enough course information" << endl;
				return courses;

			} else {
				// create a data structure and add to the collection of courses
				Course course;
				course.courseNumber = file[i][1];
				course.courseName = file[i][2];
				unsigned int j = 3;
				while (file[i][j].size() != 0) {
					course.prereq.push_back(file[i][j]);
					course.preReqs++;
					j++;
				}
				//add to end of list of courses
				courses.push_back(course);
			}
		}

	}
	catch (csv::Error& e) {
		std::cerr << e.what() << std::endl;
	}
	return courses;

}

//sort all courses by course number
void selectionSort(vector<Course>& courses) {
	//index of current min bid
	int min;
	//courses vector size
	int size_t = courses.size();
	for (int pos = 0; pos < size_t; ++pos) {
		// set min = pos
		min = pos;
		// loop over remaining elements to the right of position
		for (int i = pos + 1; i < size_t; ++i) {
			// if this element's courseNumber is less than minimum courseNumber
			if (courses[i].courseNumber.compare(courses[min].courseNumber) < 0) {
				// this element becomes the minimum
				min = i;
			}
		}
		// swap the current minimum with smaller one found
		if (min != pos) {
			// swap is a built in vector method
			swap(courses[pos], courses[min]);
		}
	}


}

void searchCourse(string SearchNumber, Course courses) {
	bool searching = true;
	unsigned int searchIndex=0;
	Course course = courses;
	while (searching) {
		if (course[searchIndex].courseNumber == SearchNumber) {
			printCourse(course[searchIndex]);
			searching = false;
		}
		else {
			searchIndex++;
		}
	}
	
}

void printCourse(Course course) {
	cout << course.courseNumber <<", " << course.courseName;
	vector<string> prereqs = course.prereq;
	for (unsigned int i = 0; i < course.prereq.size(); i++) {
		cout << ", " << prereqs.at(i);
	}
	return;
}





//Menu
void main() {
	string csvPath = "CourseInput.csv";
	//define vector to hold all the courses
	vector<Course> courses;
	string cName;
	int choice = 0;
	cout << "Welcome to the course planner." << endl;
	while (choice != 9) {
		cout << endl;
		cout << "1. Load Data Structure. " << endl;
		cout << "2. Print Course List. " << endl;
		cout << "3. Print Course. " << endl;
		cout << "9. Exit" << endl;
		cout << endl;
		cout << "What would you like to do? ";
		cin >> choice;

		switch (choice) {
		
		case 1:
			//load courses
			courses = loadCourses(csvPath);
			//sort courses by courseNumber
			selectionSort(courses);
			break;

		case 2:
			//print course list
			for (int i = 0; i < courses.size(); i++) {
				cout << courses[i].courseNumber << ", " << courses[i].courseName << endl;;
			}
			break;

		case 3:
			//print single course
			
			cout << "What course do you want to know about? ";
			cin >> cName;
			searchCourse(cName,courses);
			break;
		
		case 9:
			break;

		default:
			cout << choice << " is not a valid option" << endl;
			break;
		
		}
	}

	cout << "Thank you for using the course planner!" << endl;
	return;

}